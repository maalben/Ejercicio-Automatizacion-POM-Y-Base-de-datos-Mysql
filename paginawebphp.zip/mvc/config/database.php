<?php
return array(
    "driver"    =>"mysql",
    "host"      =>"localhost",
    "user"      =>"root",
    "pass"      =>"12345678",
    "database"  =>"pruebas",
    "charset"   =>"utf8"
);
?>
